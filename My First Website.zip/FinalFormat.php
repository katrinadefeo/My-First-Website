<html> 
<style>
img {
	display:block;
	margin-left: auto;
	margin-right: auto;
}

body {background-color:#3D0105;}



.title{
	font-family:Courier;
	font-size:150%;
	background-color:#D11220;
}



body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}



.topnav {
  overflow: hidden;
  background-color: #000A00;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #737373 ;
  color: black;
}

.topnav a.active {
	background-color: #C60200;
	color: white;
}
</style>
<br>
<br>
<br>
<br>
<br>
<br>


</html>