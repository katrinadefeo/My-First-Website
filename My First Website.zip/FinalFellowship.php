<html>
<title>Lord of the Rings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
img {
	display:block;
	margin-left: auto;
	margin-right: auto;
}

</style>

<body>

<img src="https://www.theknightsvault.com/wp-content/uploads/2017/08/Lord-of-The-Rings-Logo-PNG-Transparent-Image.png" width="100px" height="100px" align="left">

<?php
include 'FinalFormat.php';
?>

 

<div class="topnav">
  <a href="FinalHome.php">Home</a>
  <a class="active" href="FinalFellowship.php">Fellowship</a>
  <a href="Author.php">Author</a>
  <a href="Concept.php">Art & Music</a>
  <a href="FinalSet.php">Photos</a>
  <a href="FinalSearch.php">Search</a>
  <a href="FinalLogoff.php">Logoff</a>
  
</div>

<br>
<br>
<br>


<img src="https://cdn.freebiesupply.com/logos/large/2x/the-lord-of-the-rings-logo-black-and-white.png" width="10%"height="10%">

<br>
<br>


<img src="https://upload.wikimedia.org/wikipedia/commons/a/a6/The_fellowship_of_the_ring.png" width="10%" height="10%">

<br>
<br>


<p align="center">
<iframe  src="https://www.youtube.com/embed/TrJJ6ncp1fc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen width="50%" height="50%">
</iframe>
</p>

<br>
<br>


<h4 style="color:white;font-family:Calibri;">
<p style="text-align:center;">
Formed after the Council of Elrond, the Fellowship consisted of nine members: four Hobbits, two Men, one Elf, one Dwarf, and one Wizard.<br> 
It was the only known organisation ever formed in the history of Middle-earth to hold members of each of these races within it (and with the departure of the Elves and the Wizards from Middle-earth,<br>
 there would never be another like it), who largely lived and acted independently of one another. This number was chosen to match the number of Ringwraiths, or Nazgul. Merry and Pippin were never intended<br> 
 to be a part of the Fellowship, with Elrond initially considering two Elf-lords from his own house. He wished to send the two younger hobbits back to the Shire as messengers to warn other Hobbits of the growing evil.<br> 
 However, the Halflings persevered: Merry was chosen and Gandalf convinced Elrond of the loyalty of Pippin.
</p>
</h4>

<br>
<br>

<img src="https://thetinyfrogbloghome.files.wordpress.com/2019/03/fellowship8.jpg">
<br>
<br>

<br>
<br>
<img src="https://i.pinimg.com/originals/fb/69/af/fb69afcae07866ad363edc411539ba5e.png" width="5%"height="10%">
<br>

</body>
</html>