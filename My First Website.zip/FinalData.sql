CREATE DATABASE IF NOT EXISTS LOTR;

USE LOTR;

CREATE TABLE IF NOT EXISTS LOTRcharacters(
	CharacterName VARCHAR(50) NOT NULL UNIQUE,
	Classification VARCHAR(50) NOT NULL,
	PRIMARY KEY (CharacterName)
	);
	
	INSERT INTO LOTRcharacters (CharacterName, Classification)
	VALUES 
	 ('Aragorn','Good Guy'),
	 ('Arwen','Good Guy'),
	 ('Fordo Baggins','Good Guy'),
	 ('Elrond','Good Guy'),
	 ('Gandalf','Good Guy'),
	 ('Galadriel','Good Guy'),
	 ('Gimli','Good Guy'),
	 ('Legolas','Good Guy'),
	 ('Samwise Gamgee','Good Guy'),
	 ('King Theoden','Good Guy'),
	 ('Sauron','Bad Guy'),
	 ('Saruman','Bad Guy'),
	 ('Balrog','Bad Guy'),
	 ('Uruk Hai','Bad Guy'),
	 ('Gollum','Bad Guy'),
	 ('The Nazgul','Bad Guy'),
	 ('Grima Wormtongue','Bad Guy'),
	 ('Melkor','Bad Guy')
	 ;
	