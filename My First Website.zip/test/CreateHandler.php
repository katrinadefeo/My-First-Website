<html>
<head><title>CreateHandler</title><head>
<body>
<?php
session_start();

$fn = $_POST['fn'];
$ln = $_POST['ln'];
$un = $_POST['un'];
$pw = $_POST['pw'];

$qstatement = " insert into users (fname, lname, uname, pword) values ('$fn', '$ln', '$un', '$pw'); ";
echo $qstatement;

$con = mysqli_connect("127.0.0.1","root","root","Members");

$ins = mysqli_query($con, $qstatement);

mysqli_close($con);

?>
</body>
</html>