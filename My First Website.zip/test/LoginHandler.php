<html>
<head><title>LoginHandler</title><head>
<body>
<?php
session_start();

$un = $_POST['un'];
$pw = $_POST['pw'];

$query = " SELECT * FROM Users WHERE uname = '$un' AND pword = '$pw' ; " ; 


$con = mysqli_connect("127.0.0.1","root","root","Members");

if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
  
// Execute the query statement and catch the returned result table
$result = mysqli_query($con, $query);

// Fetch the first row in the returned result table
$row = mysqli_fetch_array($result);

// Check to see if there is no row returned
if ($row == null) 
{
	echo "Log in fails<br><br>" ;
}
else 
{
	echo "Log in is good!<br><br>" ;	
}

// Close the connection to MySQL
mysqli_close($con);


?>
</body>
</html>