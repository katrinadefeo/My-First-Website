<html>
<title>Lord of the Rings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
img {
	display:block;
	margin-left: auto;
	margin-right: auto;
}


</style>
<body>

<img src="https://www.theknightsvault.com/wp-content/uploads/2017/08/Lord-of-The-Rings-Logo-PNG-Transparent-Image.png" width="100px" height="100px" align="left"> 

<?php
include 'FinalFormat.php';
?>


<div class="topnav">
  <a href="FinalHome.php">Home</a>
  <a href="FinalFellowship.php">Fellowship</a>
  <a class="active" href="Author.php">Author</a> 
  <a href="Concept.php">Art & Music</a>
  <a href="FinalSet.php">Photos</a>
  <a href="FinalSearch.php">Search</a>
  <a href="FinalLogoff.php">Logoff</a>
  
  
</div>

<br>
<br>
<br>

<img src="https://cdn.freebiesupply.com/logos/large/2x/the-lord-of-the-rings-logo-black-and-white.png" width="10%"height="10%">

<br>
<br>


<img src="https://bookstr.com/wp-content/uploads/2019/08/J.R.R.-Tolkien-F-1.jpg?is-pending-load=1">

<h4 style="color:white;font-family:Calibri;">
<p style="text-align:center;">
Who was Tolkien?
John Ronald Reuel Tolkien (1892-1973) was a major scholar of the English language, specialising in Old and Middle English.<br>
Twice Professor of Anglo-Saxon (Old English) at the University of Oxford, he also wrote a number of stories, including most<br> 
famously The Hobbit (1937) and The Lord of the Rings (1954-1955), which are set in a pre-historic era in an invented version <br>
of our world which he called by the Middle English name of Middle-earth. This was peopled by Men (and women), Elves, Dwarves, <br>
Trolls, Orcs (or Goblins) and of course Hobbits. He has regularly been condemned by the Eng. Lit. establishment, with honourable <br>
exceptions, but loved by literally millions of readers worldwide. <br>

In the 1960s he was taken up by many members of the nascent counter-culture largely because of his concern with environmental issues.<br>
 In 1997 he came top of three British polls, organised respectively by Channel 4/Waterstone's, the Folio Society, and SFX, the UK’s leading <br>
 science fiction media magazine, amongst discerning readers asked to vote for the greatest book of the 20th century. Please note also that his <br>
 name is spelt Tolkien (there is no "Tolkein").
<br>
<br>




<img src= "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Tolkien_1916.jpg/220px-Tolkien_1916.jpg">
<br>

IN the summer of 1916, a young Oxford academic embarked for France as a second lieutenant in the British Expeditionary Force. The Great War,
 as World War I was known, was only half-done, but already its industrial<br>
 carnage had no parallel in European history.

"Junior officers were being killed off, a dozen a minute," recalled J. R. R. Tolkien. "Parting from my wife," he wrote, doubting that he would <br>
survive the trenches, "was like a death."

The 24-year-old Tolkien arrived in time to take part in the Battle of the Somme, a campaign intended to break the stalemate between the Allies<br> 
and Central Powers. It did not.

The first day of the battle, July 1, produced a frenzy of bloodletting. Unaware that its artillery had failed to obliterate the German dugouts, <br>
the British Army rushed to slaughter.

Before nightfall, 19,240 British soldiers - Prime Minister David Lloyd George called them "the choicest and best of our young manhood" - lay dead. <br>
That day, 100 years ago, remains the most lethal in Britain's military history.

Though the debt is largely overlooked, Tolkien's supreme literary achievement, "The Lord of the Rings," owes a great deal to his experience at the Somme. <br>
Reaching the front shortly after the offensive began, Tolkien served for four months as a battalion signals officer with the 11th Lancashire Fusiliers in the Picardy region of France. <br>
<br>
<br>

<img src="https://i.pinimg.com/originals/fb/69/af/fb69afcae07866ad363edc411539ba5e.png" width="5%"height="10%">


</body>
</html>