<html>
<title>Lord of the Rings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
img {
	display:block;
	margin-left: auto;
	margin-right: auto;
}

/* Create a column layout with Flexbox */
.row {
  display: flex;
}

/* Style the search box */
#mySearch {
  width: 100%;
  font-size: 18px;
  padding: 11px;
  border: 5px solid #ddd;
}

#myMenu li a {
  padding: 10px;
  text-decoration: none;
  color: black;
  display: block;
}


</style>

<body>

<img src="https://www.theknightsvault.com/wp-content/uploads/2017/08/Lord-of-The-Rings-Logo-PNG-Transparent-Image.png" width="100px" height="100px" align="left">

<?php
include 'FinalFormat.php';
?>

 

<div class="topnav">
  <a href="FinalHome.php">Home</a>
  <a href="FinalFellowship.php">Fellowship</a>
  <a href="Author.php">Author</a>
  <a href="Concept.php">Art & Music</a>
  <a href="FinalSet.php">Photos</a>
  <a class="active" href="FinalSearch.php">Search</a>
  <a href="FinalLogoff.php">Logoff</a>
</div>

<br>
<br>
<br>

<img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/19225f7d-38bd-4961-ac81-aa05e816999b/d6yi9hz-538bd415-7bb4-49ef-8eb1-ec4509744ef9.png/v1/fill/w_1024,h_1024,strp/lord_of_the_rings_logo_by_haleyhss_d6yi9hz-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTAyNCIsInBhdGgiOiJcL2ZcLzE5MjI1ZjdkLTM4YmQtNDk2MS1hYzgxLWFhMDVlODE2OTk5YlwvZDZ5aTloei01MzhiZDQxNS03YmI0LTQ5ZWYtOGViMS1lYzQ1MDk3NDRlZjkucG5nIiwid2lkdGgiOiI8PTEwMjQifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.Ulz9xbndoUN53_TJH2jFQekKYhRiHXLOJUuntPthodw" width="10%" height="20%">


<div class="center">
  <div class="left" >
	<div style="text-align:center;">
    <h2 style= "color: white">Search To Learn About Characters (Click on Name to Learn More) :</h2>
    <input type="text" id="mySearch" onkeyup="myFunction()" placeholder="Ex) Type Good Guy Or Bad Guy..." title="Type in a Good Guy or Bad Guy">
    <font style="font-size:25px;">
	
	<ul  id="myMenu">
	 
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Aragorn_II_Elessar"target="_blank">Aragorn (Good Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Arwen"target="_blank">Arwen (Good Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Balrogs"target="_blank">Balrog (Bad Guys) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Elrond"target="_blank">Elrond (Good Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Frodo_Baggins"target="_blank">Frodo Baggins (Good Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Galadriel"target="_blank">Galadriel (Good Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Gandalf"target="_blank">Gandalf (Good Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Gimli"target="_blank">Gimli (Good Guy)  </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Gollum"target="_blank">Gollum (Bad Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Gr%C3%ADma_Wormtongue"target="_blank">Grima Wormtongue (Bad Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Th%C3%A9oden"target="_blank"> King Theoden (Good Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Legolas"target="_blank">Legolas (Good Guy) </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Melkor"target="_blank">Melkor (Bad Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Samwise_Gamgee"target="_blank">Samwise Gamgee (Good Guy)</a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Saruman"target="_blank">Saruman (Bad Guy)  </a></li>
      <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Sauron"target="_blank">Sauron (Bad Guy) </a></li>
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Nazg%C3%BBl"target="_blank">The Nazgul "Ring Wraiths" (Bad Guys) </a></li> 
	  <li><a style ="color:white" href="https://lotr.fandom.com/wiki/Uruk-hai"target="_blank">Uruk Hai (Bad Guys) </a></li>
	
   
   </ul>
  </div>
  </div>
  </font>
 
  

<script>
function myFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("mySearch");
  filter = input.value.toUpperCase();
  ul = document.getElementById("myMenu");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
</script>
				
	</div>
	</section>
		




<img src="https://www.pngkey.com/png/full/905-9056944_lotr-witch-king-minimal-the-lord-of-the.png" width="10%"height="10%">

<br>

</body>
</html>