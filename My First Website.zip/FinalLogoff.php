<html>
<style>
body {background-color:#3D0105;}
img {
	display:block;
	margin-left: auto;
	margin-right: auto;
}

</style>
<body>
<br>
<br>
<br>
<img src = "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/19225f7d-38bd-4961-ac81-aa05e816999b/d6yi9hz-538bd415-7bb4-49ef-8eb1-ec4509744ef9.png/v1/fill/w_1024,h_1024,strp/lord_of_the_rings_logo_by_haleyhss_d6yi9hz-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTAyNCIsInBhdGgiOiJcL2ZcLzE5MjI1ZjdkLTM4YmQtNDk2MS1hYzgxLWFhMDVlODE2OTk5YlwvZDZ5aTloei01MzhiZDQxNS03YmI0LTQ5ZWYtOGViMS1lYzQ1MDk3NDRlZjkucG5nIiwid2lkdGgiOiI8PTEwMjQifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.Ulz9xbndoUN53_TJH2jFQekKYhRiHXLOJUuntPthodw" width="30%" height="50%"> 


<?php
session_start();
session_destroy();
echo "<br><br><br>";

echo "<p><center><span style= \"color: white; font-size: 50px;\"> Goodbye, Mellon</a></center></p>";
echo "<p><center><span style= \"color: white; font-size: 50px;\"> You Have Been Logged Out</a></center></p>";
echo "<center><span style= \"color: white; font-size: 50px;\"><a href='FinalLogin2.html'>Login Here</center>";
exit();


?>

