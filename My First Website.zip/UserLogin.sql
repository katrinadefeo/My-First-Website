CREATE DATABASE IF NOT EXISTS Members;

USE Members;

CREATE TABLE IF NOT EXISTS Users(
	uname VARCHAR(50) NOT NULL UNIQUE,
	pword VARCHAR(50) NOT NULL,
	PRIMARY KEY (uname)
	);
	
	INSERT INTO Users (uname, pword)
	VALUES ('root','root');
	
	