<html>
<head>
<title>Insert Result</title>
</head>
<style>

body {background-color:#3D0105;}
</style>

<body>

<?php 
session_start();

$un = $_POST['un'];
$pw = $_POST['pw'];

$qstatement = " insert into Users (uname, pword) values ('$un', '$pw'); ";
echo "<br><br><br><br><br><br><br><br><br><br><br><br><br>";

echo "<p><center><span style= \"color:white; font-size: 20px;\">Account Created</span> <span style =\"color:green; font-size: 20px;\">Successfully.</span></a><center></p>";
echo "<p><center><span style= \"color:white; font-size: 20px;\">Click<a href='FinalLogin2.html'> Here to Return to Login Page</span></a></center></p>";

/*echo "<br><br><br><br><br><br><br><br><br><br><br><br><br>";
	echo "<p><center><span style= \"color: white; font-size: 50px;\"> Login</span> <span style= \"color: red; font-size: 50px\"> &nbsp;Fails</span> <br><br>" ;
	echo "<span style= \"color:white; font-size: 20px;\">Click <a href='FinalLogin2.html'> Here to Login Again</span></a></center></p>";
*/

$connect = mysqli_connect("127.0.0.1","root", "root", "Members");


$display = mysqli_query($connect, $qstatement);

mysqli_close($connect);

?>



</body>
</html>