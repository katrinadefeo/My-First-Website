- In Heidi under tools and user manager add a user account

- Create a username and password called (root,root).

- On the Login page the default username and password will also be root,root. 

- To demonstrate a connection to the database, try creating an account using the create an account link. 

- Once the account has succesfully been created it will give you a link back to the login page. From there use your   newly created username and password

- Once you have made it the the Main Menu on the website keep in mind that some pictures and links can be engaged with
  (Ex. Pictures in the photos tab can be engaged with and the links in the search can be engaged with)

