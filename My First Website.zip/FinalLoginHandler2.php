<html>

<style>

body {background-color:#3D0105;}
</style>



<?php

session_start();

$un = $_POST['un'];
$pw = $_POST['pw'];

$query =" SELECT * FROM Users WHERE uname = '$un' AND pword ='$pw' ;" ;


$connect = mysqli_connect("127.0.0.1", "root", "root", "Members");



if(mysqli_connect_errno())
{
	echo "Failed to connect" . mysqli_connect_error();
}

$result = mysqli_query($connect, $query);

$row = mysqli_fetch_array($result);

if($row == null)
{
	
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br>";
	echo "<p><center><span style= \"color: white; font-size: 50px;\"> Login</span> <span style= \"color: red; font-size: 50px\"> &nbsp;Fails</span> <br><br>" ;
	echo "<span style= \"color:white; font-size: 20px;\">Click <a href='FinalLogin2.html'> Here to Login Again</span></a></center></p>";
	
}

else{
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br>";
	echo "<p><center><span style= \"color: white; font-size: 50px;\">Login is </span> <span style=\"color: green; font-size: 50px\"> Good!</span><br><br>";
	echo "<p><center><span style= \"color: white; font-size: 20px;\">Welcome! Click the Link below to Access Katrina's Site<br>";
	echo"Link to <a href='FinalHome.php'>Katrina's Site</a></p>";
	
}

 mysqli_close($connect); 






?>